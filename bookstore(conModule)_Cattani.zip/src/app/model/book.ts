export interface BookInterface {
    titulo?: string;
    idioma?: string;
    descripcion?: string;
    portada?: string;
    precio?: string;
    link_amazon?: string;
    oferta?: string;
    id?: string;
    userUId?: string;
}